create definer = root@`%` trigger trig_integral
    after INSERT
    on stu_integral_info
    for each row
Begin
    update tb_student 
    set tb_student.integral = tb_student.integral+new.other_value
    where new.stuid = tb_student.stuid;
END;

