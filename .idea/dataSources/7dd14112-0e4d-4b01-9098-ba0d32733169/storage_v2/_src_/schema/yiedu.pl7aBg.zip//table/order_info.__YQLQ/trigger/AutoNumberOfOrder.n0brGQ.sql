create definer = root@`%` trigger AutoNumberOfOrder
    before INSERT
    on order_info
    for each row
BEGIN
   SET @two = (SELECT DATE_FORMAT(NOW(), '%Y%m%d'));
   SET @tmp = (SELECT IFNULL(order_id,'') AS a
   FROM order_info 
   WHERE substring(order_id,3,8) = @two
   order by order_id DESC limit 1);
   SET @three = '001';
   IF @tmp != '' THEN
   SET @three = (cast((substring(@tmp,-3)) as unsigned integer)+1);
   END IF;
   SET new.order_id =(SELECT CONCAT("CD",@two,LPAD(@three,3,'0')));
END;

