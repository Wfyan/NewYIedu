create definer = root@`%` trigger AutoNumberOfTeacher
    before INSERT
    on tb_teacher
    for each row
BEGIN
   SET @two = (SELECT DATE_FORMAT(NOW(), '%Y%m%d'));
   SET @tmp = (SELECT IFNULL(tecid,'') AS a
   FROM tb_teacher
   WHERE substring(tecid,3,8) = @two
   order by tecid DESC limit 1);
   SET @three = '001';
   IF @tmp != '' THEN
   SET @three = (cast((substring(@tmp,-3)) as unsigned integer)+1);
   END IF;
   SET new.tecid =(SELECT CONCAT("TC",@two,LPAD(@three,3,'0')));
END;

