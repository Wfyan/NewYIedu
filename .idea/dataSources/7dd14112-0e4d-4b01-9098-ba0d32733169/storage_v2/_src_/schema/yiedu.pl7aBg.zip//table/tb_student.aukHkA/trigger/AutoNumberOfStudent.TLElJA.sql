create definer = root@`%` trigger AutoNumberOfStudent
    before INSERT
    on tb_student
    for each row
BEGIN
   SET @two = (SELECT DATE_FORMAT(NOW(), '%Y%m%d'));
   SET @tmp = (SELECT IFNULL(stuid,'') AS a
   FROM tb_student 
   WHERE substring(stuid,3,8) = @two
   order by stuid DESC limit 1);
   SET @three = '001';
   IF @tmp != '' THEN
   SET @three = (cast((substring(@tmp,-3)) as unsigned integer)+1);
   END IF;
   SET new.stuid =(SELECT CONCAT("ST",@two,LPAD(@three,3,'0')));
END;

